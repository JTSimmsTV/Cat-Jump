gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects1= [];
gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2= [];
gdjs.Game_32SceneCode.GDBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects1= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects2= [];
gdjs.Game_32SceneCode.GDJoystickObjects1= [];
gdjs.Game_32SceneCode.GDJoystickObjects2= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2= [];
gdjs.Game_32SceneCode.GDNewTextObjects1= [];
gdjs.Game_32SceneCode.GDNewTextObjects2= [];
gdjs.Game_32SceneCode.GDNewText2Objects1= [];
gdjs.Game_32SceneCode.GDNewText2Objects2= [];
gdjs.Game_32SceneCode.GDLadderObjects1= [];
gdjs.Game_32SceneCode.GDLadderObjects2= [];
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects1= [];
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects2= [];
gdjs.Game_32SceneCode.GDNewLightObjects1= [];
gdjs.Game_32SceneCode.GDNewLightObjects2= [];
gdjs.Game_32SceneCode.GDNewLight2Objects1= [];
gdjs.Game_32SceneCode.GDNewLight2Objects2= [];
gdjs.Game_32SceneCode.GDCat1Objects1= [];
gdjs.Game_32SceneCode.GDCat1Objects2= [];
gdjs.Game_32SceneCode.GDSign1Objects1= [];
gdjs.Game_32SceneCode.GDSign1Objects2= [];
gdjs.Game_32SceneCode.GDCat2Objects1= [];
gdjs.Game_32SceneCode.GDCat2Objects2= [];
gdjs.Game_32SceneCode.GDAlternativeBush3Objects1= [];
gdjs.Game_32SceneCode.GDAlternativeBush3Objects2= [];
gdjs.Game_32SceneCode.GDGreenArrowObjects1= [];
gdjs.Game_32SceneCode.GDGreenArrowObjects2= [];
gdjs.Game_32SceneCode.GDAppleObjects1= [];
gdjs.Game_32SceneCode.GDAppleObjects2= [];
gdjs.Game_32SceneCode.GDNewSpriteObjects1= [];
gdjs.Game_32SceneCode.GDNewSpriteObjects2= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects2Objects = Hashtable.newFrom({"Platformer_Character": gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCat1Objects2Objects = Hashtable.newFrom({"Cat1": gdjs.Game_32SceneCode.GDCat1Objects2});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects2Objects = Hashtable.newFrom({"Platformer_Character": gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCat2Objects2Objects = Hashtable.newFrom({"Cat2": gdjs.Game_32SceneCode.GDCat2Objects2});
gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

};gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects1Objects = Hashtable.newFrom({"Platformer_Character": gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDAppleObjects1Objects = Hashtable.newFrom({"Apple": gdjs.Game_32SceneCode.GDAppleObjects1});
gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{


let stopDoWhile_0 = false;
do {
gdjs.copyArray(runtimeScene.getObjects("Cat1"), gdjs.Game_32SceneCode.GDCat1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platformer_Character"), gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCat1Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCat1Objects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCat1Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}
{ //Subevents: 
gdjs.Game_32SceneCode.eventsList0(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


{


let stopDoWhile_0 = false;
do {
gdjs.copyArray(runtimeScene.getObjects("Cat2"), gdjs.Game_32SceneCode.GDCat2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Platformer_Character"), gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects2Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDCat2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCat2Objects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCat2Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 10.aac", false, 100, 1);
}
{ //Subevents: 
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


{

gdjs.copyArray(runtimeScene.getObjects("Apple"), gdjs.Game_32SceneCode.GDAppleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platformer_Character"), gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlatformer_95959595CharacterObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDAppleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDAppleObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDAppleObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDAppleObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewText2Objects1.length = 0;
gdjs.Game_32SceneCode.GDNewText2Objects2.length = 0;
gdjs.Game_32SceneCode.GDLadderObjects1.length = 0;
gdjs.Game_32SceneCode.GDLadderObjects2.length = 0;
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewLightObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewLightObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewLight2Objects1.length = 0;
gdjs.Game_32SceneCode.GDNewLight2Objects2.length = 0;
gdjs.Game_32SceneCode.GDCat1Objects1.length = 0;
gdjs.Game_32SceneCode.GDCat1Objects2.length = 0;
gdjs.Game_32SceneCode.GDSign1Objects1.length = 0;
gdjs.Game_32SceneCode.GDSign1Objects2.length = 0;
gdjs.Game_32SceneCode.GDCat2Objects1.length = 0;
gdjs.Game_32SceneCode.GDCat2Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternativeBush3Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternativeBush3Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreenArrowObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreenArrowObjects2.length = 0;
gdjs.Game_32SceneCode.GDAppleObjects1.length = 0;
gdjs.Game_32SceneCode.GDAppleObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList2(runtimeScene);
gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatformer_9595CharacterObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewText2Objects1.length = 0;
gdjs.Game_32SceneCode.GDNewText2Objects2.length = 0;
gdjs.Game_32SceneCode.GDLadderObjects1.length = 0;
gdjs.Game_32SceneCode.GDLadderObjects2.length = 0;
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDBottomArrowRoundButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewLightObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewLightObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewLight2Objects1.length = 0;
gdjs.Game_32SceneCode.GDNewLight2Objects2.length = 0;
gdjs.Game_32SceneCode.GDCat1Objects1.length = 0;
gdjs.Game_32SceneCode.GDCat1Objects2.length = 0;
gdjs.Game_32SceneCode.GDSign1Objects1.length = 0;
gdjs.Game_32SceneCode.GDSign1Objects2.length = 0;
gdjs.Game_32SceneCode.GDCat2Objects1.length = 0;
gdjs.Game_32SceneCode.GDCat2Objects2.length = 0;
gdjs.Game_32SceneCode.GDAlternativeBush3Objects1.length = 0;
gdjs.Game_32SceneCode.GDAlternativeBush3Objects2.length = 0;
gdjs.Game_32SceneCode.GDGreenArrowObjects1.length = 0;
gdjs.Game_32SceneCode.GDGreenArrowObjects2.length = 0;
gdjs.Game_32SceneCode.GDAppleObjects1.length = 0;
gdjs.Game_32SceneCode.GDAppleObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
